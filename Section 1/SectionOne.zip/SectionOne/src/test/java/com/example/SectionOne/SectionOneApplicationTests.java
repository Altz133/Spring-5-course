package com.example.SectionOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SectionOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
