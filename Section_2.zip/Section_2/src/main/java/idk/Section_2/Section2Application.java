package idk.Section_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section2Application {

	public static void main(String[] args) {
		SpringApplication.run(Section2Application.class, args);
	}

}
