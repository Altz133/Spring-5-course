package idk.Section_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
